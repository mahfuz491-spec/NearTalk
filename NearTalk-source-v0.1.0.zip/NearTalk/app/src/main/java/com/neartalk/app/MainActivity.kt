package com.neartalk.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newCachedThreadPool()
    private var serverSocket: ServerSocket? = null
    @Volatile private var connection: Socket? = null
    @Volatile private var writer: PrintWriter? = null
    private lateinit var logView: TextView
    private lateinit var hostInput: EditText
    private lateinit var messageInput: EditText
    private val port = 8988

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        addLog("NearTalk 0.1.0 — পরীক্ষামূলক অফলাইন চ্যাট")
        addLog("দুই ফোন একই Wi-Fi/হটস্পট নেটওয়ার্কে যুক্ত করুন।")
        addLog("এক ফোনে Server চালু করুন, অন্য ফোনে Server ফোনের IP লিখে Connect চাপুন।")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 16)
        }
        val title = TextView(this).apply {
            text = "NearTalk"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val hint = TextView(this).apply {
            text = "অফলাইন লোকাল চ্যাট • Port $port"
            textSize = 14f
            gravity = Gravity.CENTER
        }
        root.addView(hint)

        val serverButton = Button(this).apply {
            text = "এই ফোনে Server চালু করুন"
            setOnClickListener { startServer() }
        }
        root.addView(serverButton, LinearLayout.LayoutParams(-1, -2))

        hostInput = EditText(this).apply {
            hint = "Server ফোনের IP (যেমন 192.168.43.1)"
            singleLine = true
            setText("192.168.43.1")
        }
        root.addView(hostInput, LinearLayout.LayoutParams(-1, -2))

        val connectButton = Button(this).apply {
            text = "অন্য ফোনে Connect করুন"
            setOnClickListener { connectToHost() }
        }
        root.addView(connectButton, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this)
        logView = TextView(this).apply {
            textSize = 15f
            setPadding(10, 10, 10, 10)
        }
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        messageInput = EditText(this).apply {
            hint = "মেসেজ লিখুন"
        }
        root.addView(messageInput, LinearLayout.LayoutParams(-1, -2))

        val sendButton = Button(this).apply {
            text = "মেসেজ পাঠান"
            setOnClickListener { sendMessage() }
        }
        root.addView(sendButton, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun startServer() {
        executor.execute {
            try {
                if (serverSocket != null && serverSocket?.isClosed == false) {
                    addLog("Server আগে থেকেই চালু আছে।")
                    return@execute
                }
                val server = ServerSocket(port)
                serverSocket = server
                addLog("Server চালু হয়েছে। এই ফোনের হটস্পট IP অন্য ফোনে লিখুন।")
                val client = server.accept()
                attach(client, "অন্য ফোন সংযুক্ত হয়েছে")
            } catch (e: Exception) {
                addLog("Server সমস্যা: ${e.message}")
            }
        }
    }

    private fun connectToHost() {
        val host = hostInput.text.toString().trim()
        if (host.isBlank()) {
            addLog("আগে Server ফোনের IP লিখুন।")
            return
        }
        executor.execute {
            try {
                val socket = Socket(host, port)
                attach(socket, "Server ফোনে সংযোগ হয়েছে")
            } catch (e: Exception) {
                addLog("সংযোগ হয়নি: ${e.message}")
            }
        }
    }

    private fun attach(socket: Socket, message: String) {
        connection = socket
        writer = PrintWriter(socket.getOutputStream(), true)
        addLog(message)
        executor.execute {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
                while (!socket.isClosed) {
                    val line = reader.readLine() ?: break
                    addLog("অন্য ফোন: $line")
                }
                addLog("সংযোগ বিচ্ছিন্ন হয়েছে।")
            } catch (e: Exception) {
                addLog("রিসিভ সমস্যা: ${e.message}")
            }
        }
    }

    private fun sendMessage() {
        val message = messageInput.text.toString().trim()
        if (message.isEmpty()) return
        executor.execute {
            val out = writer
            if (out == null || connection?.isConnected != true) {
                addLog("এখনো অন্য ফোনে সংযোগ হয়নি।")
            } else {
                out.println(message)
                addLog("আপনি: $message")
                runOnUiThread { messageInput.setText("") }
            }
        }
    }

    private fun addLog(message: String) {
        runOnUiThread {
            logView.append("$message\n\n")
        }
    }

    override fun onDestroy() {
        try { connection?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }
}
