# NearTalk

NearTalk is an experimental Android offline messenger prototype.

## Current prototype
- Manual local-network connection using a Wi-Fi hotspot or the same Wi-Fi network.
- One phone starts a local TCP server on port 8988.
- The second phone connects using the server phone's local IP address.
- Basic text messages.

## Build
Open this project in Android Studio and build the `app` debug variant, or use the included GitHub Actions workflow.

## Important
This is an early prototype, not a finished messenger. It does not yet include automatic discovery, file transfer, encryption, group chat, voice calls, or video calls. The hotspot may need to be enabled manually in Android settings. The server phone's IP address can vary by device.
